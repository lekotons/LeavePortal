﻿google.charts.load('current', { 'packages': ['corechart', 'bar'] });
google.charts.setOnLoadCallback(GetBarChartData);

$('#submitButton').click(function () {
    debugger;
    GetBarChartData();
});


function GetBarChartData() {
    var cycle = $('#cycle').val();

    $.ajax({
        url: '/Reports/GetCriticalComplianceRateReport',
        type: 'GET',
        dataType: 'json',
        data: {
            cycle: cycle
        },
        error: function () {
            callback();
        },
        success: function (data) {
         
            DrawBarGraph(data, cycle);
        }
    });
}


function DrawBarGraph(data, cycle) {

    var plotData = new google.visualization.DataTable();
    plotData.addColumn('string', 'N');
    plotData.addColumn('number', 'No of times rule has been addressed');

    for (var i = 0; i < data.length; i++) {
        plotData.addRow([data[i].Title, data[i].Count]);
    }

    var options = {
        title: 'CIRTICAL COMPLIANCE REPORT FOR CYCLE  ' + cycle,
        chartArea: { width: '70%' },
       // explorer: {axis: 'horizontal', keepInBounds: true},
        vAxis: {
             title: 'Number of Occurances'
        },
        hAxis: {
            //  title: 'SDIP Average Score',
            minValue: 0,
            showTextEvery: 1,
            slantedText: 'true',
            slantedTextAngle: '90',
            legend: { position: "bottom" },
           // ticks: [0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5]
        },
        //Axis: {showTextEvery: 1},
        //hAxis: {slantedText:'true'},
        //hAxis: {slantedTextAngle: '90'},
        //isStacked: true
    };
    
    var chart = new google.visualization.ColumnChart(document.getElementById('barChartContainer'));
    chart.draw(plotData, options);
}