﻿$('#submitButton').click(function () {

    var cycle = $('#cycle').val();
    var sphere = $('#sphere').val();
    window.location.href = "/Reports/GetRatingCount?cycle=" + cycle + "&sphere=" + sphere;

});
