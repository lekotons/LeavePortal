﻿function sphereAssessmentChanged() {
    var sphere = this.value();
    var grid = $('#gridAssessment').data("kendoGrid");

    if (sphere) {
        grid.dataSource.filter({ field: "Sphere", operator: "eq", value: sphere });
    }
    else {
        grid.dataSource.filter({});
    }
}

function sphereBelowChanged() {
    var sphere = this.value();
    var grid = $('#gridBelow').data("kendoGrid");

    if (sphere) {
        grid.dataSource.filter({ field: "Sphere", operator: "eq", value: sphere });
    }
    else {
        grid.dataSource.filter({});
    }
}

function sphereAboveChanged() {
    var sphere = this.value();
    var grid = $('#gridAbove').data("kendoGrid");

    if (sphere) {
        grid.dataSource.filter({ field: "Sphere", operator: "eq", value: sphere });
    }
    else {
        grid.dataSource.filter({});
    }
}

function sphereAverageChanged() {
    var sphere = this.value();
    var grid = $('#gridAverage').data("kendoGrid");

    if (sphere) {
        grid.dataSource.filter({ field: "Sphere", operator: "eq", value: sphere });
    }
    else {
        grid.dataSource.filter({});
    }
}

function Noty(message, type) {
    var n = noty({
        text: message,
        type: type,
        animation: {
            open: { height: 'toggle' },
            close: { height: 'toggle' },
            easing: 'swing',
            speed: 500 // opening & closing animation speed
        }
    });
}
