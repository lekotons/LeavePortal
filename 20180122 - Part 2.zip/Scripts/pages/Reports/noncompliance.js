﻿$('#submitButton').click(function () {

    var cycle = $('#cycle').val();
    window.location.href = "/Reports/GetNonComplianceReport?cycle=" + cycle;
});

$('#export').click(function () {
    $.ajax({
        url: '/Excel/ExportNonCompliance',
        type: 'POST',
        dataType: 'json',
        contentType: "application/json; charset=utf-8",
        data: kendo.stringify({
            model: $("#gridNonCompliance").data("kendoGrid").dataSource.view()
        }),
        success: function (result) {
            window.location.href = "/Excel/GenerateNonComplianceExcelFile?guid=" + result;

        }
    });
});