﻿$('#submitButton').click(function () {

    var cycle = $('#cycle').val();
    window.location.href = "/Reports/GetNotMetCompliance?cycle=" + cycle;

});

$('#export').click(function () {


    $.ajax({
        url: '/Excel/ExportNotMetComplianceAssessmentDetails',
        type: 'POST',
        dataType: 'json',
        contentType: "application/json; charset=utf-8",
        data: kendo.stringify({
            model: $("#gridQuality").data("kendoGrid").dataSource.view()
        }),
        success: function (result) {
            window.location.href = "/Excel/GenerateNotMetComplianceAssessmentExcelFile?guid=" + result;

        }
    });
});