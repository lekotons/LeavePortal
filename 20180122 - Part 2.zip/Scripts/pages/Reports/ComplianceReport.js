﻿ $('#submitButton').click(function () {
        var cycle = $('#cycle').val();

        window.location.href = "/Reports/GetComplianceReport?cycle=" + cycle;
    });
 $('#exportSphereBtn').click(function () {

     debugger;
     $.ajax({
         url: '/Excel/ExportComplianceAssessmentDetails',
         type: 'POST',
         dataType: 'json',
         contentType: "application/json; charset=utf-8",
         data: kendo.stringify({
             model: $("#gridCompliance").data("kendoGrid").dataSource.view()
         }),
         success: function (result) {
             window.location.href = "/Excel/GenerateComplianceAssessmentExcelFile?guid=" + result;

         }
     });
 });