﻿google.charts.load('current', { 'packages': ['corechart', 'bar'] });
google.charts.setOnLoadCallback(GetPieChartData);
google.charts.setOnLoadCallback(GetBarChartData);

$('#submitButton').click(function () {
    GetPieChartData();
    GetBarChartData();
});

function GetPieChartData() {
    var cycle = $('#cycle').val();
    var sphere = $('#sphere').val();

    $.ajax({
        url: '/Reports/GetRatingScores',
        type: 'GET',
        dataType: 'json',
        data: {
            cycle: cycle,
            sphere: sphere
        },
        error: function () {
            callback();
        },
        success: function (data) {
            DrawPieGraph(data, cycle, sphere);
        }
    });
}

function GetBarChartData() {
    var cycle = $('#cycle').val();
    var sphere = $('#sphere').val();

    $.ajax({
        url: '/Reports/GetDepartmentScores',
        type: 'GET',
        dataType: 'json',
        data: {
            cycle: cycle,
            sphere: sphere
        },
        error: function () {
            callback();
        },
        success: function (data) {
            DrawBarGraph(data, cycle, sphere);
        }
    });
}

function DrawPieGraph(data, cycle, sphere) {

    var plotData = new google.visualization.DataTable();
    plotData.addColumn('string', 'N');
    plotData.addColumn('number', 'Percentage');

    for (var i = 0; i < data.length; i++) {
        plotData.addRow([data[i].Rating, data[i].Percentage]);
    }

    var options = {
        title: cycle + ' ' + sphere.toUpperCase() + ' DEPARTMENTS SDIP RATING SCORES',
        is3D: true,
        legend: {
            maxLines: 1,
            textStyle: {
                fontSize: 15
            }
        },
    };

    var chart = new google.visualization.PieChart(document.getElementById('pieChartContainer'));
    chart.draw(plotData, options);
}

function DrawBarGraph(data, cycle, sphere) {

    var plotData = new google.visualization.DataTable();
    plotData.addColumn('string', 'N');
    plotData.addColumn('number', 'AverageScore');

    for (var i = 0; i < data.length; i++) {
        plotData.addRow([data[i].Department, data[i].AverageScore]);
    }

    var options = {
        title: cycle + ' SDIP SCORES FOR ' + sphere.toUpperCase() + ' DEPARTMENTS',
        chartArea: { width: '50%' },
        vAxis: {
            // title: 'Departments'
        },
        hAxis: {
            //  title: 'SDIP Average Score',
            minValue: 0,
            ticks: [0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5]
        }
    };

    var chart = new google.visualization.BarChart(document.getElementById('barChartContainer'));
    chart.draw(plotData, options);
}