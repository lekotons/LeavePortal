﻿$(document).ready(function () {

    var defaultService = 1;

    bootbox.prompt({
        title: "How many services will be addressed?",
        inputType: 'select',
        animate: true,
        closeButton: false,
        inputOptions: [
            {
                text: 'Choose . . .',
                value: '',
            },
            {
                text: 'One service',
                value: '1',
            },
            {
                text: 'Two services',
                value: '2',
            },
            {
                text: 'Three services',
                value: '3',
            }
        ],
        callback: function (result) {

            if (result === null) {
                $("#NoOfServices").val(defaultService);
            }

            if (isNaN(result)) {
                return false;
            }

            if (result === '') {
                return false;
            }

            $("#NoOfServices").val(result);
            DuplicateServices(result);
        }
    });

});

$(function () {

    $('.k-header').next().slideToggle();
    $('.k-header').first().next().slideToggle();

    $('.k-header').click(function () {
        $(this).next().slideToggle();
    });

    $('#saveButton').click(function (e) {

        var form = $('form');
        e.preventDefault();

        NotyConfirm(form);
    });

    $('input[type=radio]').change(function () {

        var currentCheckBox = $(this);
        var selectedValue = currentCheckBox.val();

        var controlName = $(this).attr("name");
        var questionStringIndex = controlName.substring(0, controlName.indexOf('.'));
        var firstIndex = questionStringIndex.indexOf('[') + 1;
        var lastIndex = questionStringIndex.lastIndexOf(']');
        var questionIndex = questionStringIndex.substring(firstIndex, lastIndex);

        var questionTypeControlName = questionIndex + '_AnswerMethod';

        var answerMethod = $('#' + questionTypeControlName).val();


        if (answerMethod === 'Multiple') {

            var defaultService = 1;
            var services = null;

            var descriptionControlName = questionIndex + '_Description';
            var evidenceControlName = questionIndex + '_Evidence';
            var description = $('#' + descriptionControlName).val();
            var evidence = $('#' + evidenceControlName).val();

            var selectedServices = $("#NoOfServices").val();

            $("#" + questionIndex + "_PointsMultiple").val(selectedServices);

        } else {

            var controlName = $(this).attr("name");
            var questionStringIndex = controlName.substring(0, controlName.indexOf('.'));
            var questionIndex = questionStringIndex.substring(1, 2);

            $("#" + questionIndex + "_PointsMultiple").val(1);
        }
    });

});

function DuplicateServices(services) {

    var countConstant = 113;

    $('.table tr').each(function (iCnt, row) {

        iCnt++;

        var controlName = "#" + iCnt + "_AnswerMethod";
        var answerMethod = $(controlName).val();

        if (answerMethod === "Multiple") {
            for (var i = 1; i < services; i++) {

                var thisRow = $(this).closest('tbody > tr')[0];

                if (thisRow === undefined) {
                    return;
                }

                var clone = $(thisRow).clone().insertAfter(thisRow);

                var index = (new Date()).getTime();
                var uniqueRowId = $(clone).find(".index");
                var uniqueRowSDIPID = $(clone).find(".sdipid");
                var uniqueRowQuestionId = $(clone).find(".questionid");
                var uniqueRowPoints = $(clone).find(".points");
                var uniqueRowSectionName = $(clone).find(".sectionname");
                var uniqueRowFormulaGroup = $(clone).find(".formulagroup");
                var uniqueRowAnswerMotivation = $(clone).find(".answermotivation");

                countConstant = countConstant + 1;

                var newRowName = "[" + countConstant + "].Id";
                $(uniqueRowId).attr('name', "[" + countConstant + "].Id");
                $(uniqueRowSDIPID).attr('name', "[" + countConstant + "].SDIPID");
                $(uniqueRowQuestionId).attr('name', "[" + countConstant + "].QuestionId");
                $(uniqueRowPoints).attr('name', "[" + countConstant + "].Points");
                $(uniqueRowSectionName).attr('name', "[" + countConstant + "].SectionName");
                $(uniqueRowFormulaGroup).attr('name', "[" + countConstant + "].FormulaGroup");
                $(uniqueRowAnswerMotivation).attr('name', "[" + countConstant + "].AnswerMotivation");

                var checkBox = $(thisRow).find("input[type='radio']");
                var newId = "MyObject_" + countConstant + "_Checked";

                $(checkBox).attr('id', newId);
                $(checkBox).attr('name', "[" + countConstant + "].Answered");

                var form = $('form');
                form.data('validator', null);
                $.validator.unobtrusive.parse(form);

            }
        }
    });
}

function NotyConfirm(form) {

    noty({
        title: 'Confirm assessment submission',
        text: 'Are you sure you want to submit the asssessment form?',
        layout: 'center',
        modal: true,
        buttons: [
          {
              addClass: 'btn btn-primary', text: 'Yes', onClick: function ($noty) {

                  $noty.close();

                  var comment = $('#ConclusionComment').val();

                  if (comment) {
                      form.submit();
                  } else {
                      Noty('Please input the final assessment comment.', 'error');
                  }
              }
          },
          {
              addClass: 'btn btn-danger', text: 'No', onClick: function ($noty) {
                  $noty.close();
                  Noty('You have cancelled the request.', 'warning');
              }
          }
        ]
    });
}

function Noty(message, type) {
    var n = noty({
        text: message,
        type: type,
        timeout: 2000,
        animation: {
            open: { height: 'toggle' },
            close: { height: 'toggle' },
            easing: 'swing',
            speed: 500
        }
    });
}