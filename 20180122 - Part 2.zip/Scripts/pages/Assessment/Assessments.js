﻿function AssessSDIP(e) {
    var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
    var _id = dataItem.SDIPID;

      //@*window.location.href = "@Url.Action("Index", "Assessment")?SDIPID=" + _id*@
       window.location.href = "/Assessment?SDIPID=" + _id
}

function dataBound() {

}

function ViewDetails(e) {
    var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
    var _id = dataItem.SDIPID;

   // @*window.location.href = "@Url.Action("SDPIRatingDetails", "SDPIDoc")?SDIPID=" + _id;*@
    window.location.href = "/SDPIDoc/SDPIRatingDetails?SDIPID=" + _id;}

function RejectAssessment(e) {

    var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
    var _id = dataItem.SDIPID;
    var _department = dataItem.Department;
    var _cycle = dataItem.Cycle;

    bootbox.prompt({
        title: "Please capture rejection reason",
        inputType: 'textarea',
        size: 'large',
        callback: function (result) {
               
            if (result) {
               // @*window.location.href = "@Url.Action("RejectSDIP", "Assessment")?SDIPID=" + _id + "&department=" + _department + "&cycle=" + _cycle +
                //  "&rejectionReason=" + result;*@
                window.location.href = "/Assessment/RejectSDIP?SDIPID=" + _id + "&department=" + _department + "&cycle=" + _cycle + "&rejectionReason=" + result;
            }
        }
    });
}

function CloseAssessment(e) {
    var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
    var _id = dataItem.SDIPID;
    var _department = dataItem.Department;
    var _cycle = dataItem.Cycle;

     // window.location.href = "@Url.Action("CloseSDIP", "Assessment")?SDIPID=" + _id;*@
    window.location.href = "/Assessment/CloseSDIP?SDIPID=" + _id;}

function DownloadFile(e) {

    var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
    var _id = dataItem.SDIPID;

    // window.location.href = "@Url.Action("DownloadSDIPDocument", "SDPIDoc")?SDIPID=" + _id;*@
    window.location.href = "/SDPIDoc/DownloadSDIPDocument?SDIPID=" + _id;}