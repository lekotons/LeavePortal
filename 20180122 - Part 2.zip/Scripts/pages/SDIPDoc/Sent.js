﻿function DownloadFile(e) {

    var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
    var _id = dataItem.SDIPID;

    window.location.href = "/SDPIDoc/DownloadSDIPDocument?SDIPID=" + _id;
}