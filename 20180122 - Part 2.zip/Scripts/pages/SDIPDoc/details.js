﻿function onRowBound(e) {
    var gridData = e.sender._data;

    $.each(gridData, function (index, row) {

        if (row.Answer === "Yes") {

            $('tr[data-uid="' + row.uid + '"] ').css("background-color", "Green");
            $('tr[data-uid="' + row.uid + '"] ').css("color", "White");
            row.Answer = "<div class='k-icon k-i-tick' /><div>";
        }
        else if (row.Answer === "No") {
            $('tr[data-uid="' + row.uid + '"] ').css("background-color", "Red");
            $('tr[data-uid="' + row.uid + '"] ').css("color", "White");
            row.Answer = "<div class='k-icon k-i-close' /><div>";
        }
    });
}