﻿function DownloadFile(e) {

    var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
    var _id = dataItem.SDIPID;

    window.location.href = "/SDPIDoc/DownloadSDIPDocument?SDIPID=" + _id;
}

function SubmitFinal(e) {
    var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
    var _id = dataItem.SDIPID;

    window.location.href = "/SDPIDoc/ChangeStatus?SDIPID=" + _id + "&Status=Final";

}

function SubmitReview(e) {
    var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
    var _id = dataItem.SDIPID;

    window.location.href = "/SDPIDoc/ChangeStatus?SDIPID=" + _id + "&Status=Review";
}