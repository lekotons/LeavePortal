﻿
$('#submitFinalButton').click(function (e) {
    $('#status').val('Final');
    e.preventDefault();

    var form = $('form');
    NotyConfirm(form);
});

$('#submitReviewButton').click(function (e) {
    $('#status').val('Review');
    e.preventDefault();

    var form = $('form');
    NotyConfirm(form);
});

$('#saveButton').click(function (e) {
    $('#status').val('Save');
    e.preventDefault();

    var form = $('form');
    NotyConfirm(form);
});

function NotyConfirm(form) {

    noty({
        text: 'Please note that submitting the SDIP may overwrite an already submitted document if exists. Do you want to continue?',
        layout: 'center',
        modal: true,
        buttons: [
          {
              addClass: 'btn btn-primary', text: 'Yes', onClick: function ($noty) {

                  $noty.close();
                  form.submit();
              }
          },
          {
              addClass: 'btn btn-danger', text: 'No', onClick: function ($noty) {
                  $noty.close();
                  Noty('You have cancelled the request.', 'warning');
              }
          }
        ]
    });
}

function Noty(message, type) {
    var n = noty({
        text: message,
        type: type,
        timeout: 2000,
        animation: {
            open: { height: 'toggle' },
            close: { height: 'toggle' },
            easing: 'swing',
            speed: 500
        }
    });
}