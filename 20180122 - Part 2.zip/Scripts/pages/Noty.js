﻿

    function Noty(message, type) {
        var n = noty({
            text: message,
            type: type,
            animation: {
                open: { height: 'toggle' },
                close: { height: 'toggle' },
                easing: 'swing',
                speed: 500 // opening & closing animation speed
            }
        });
    }